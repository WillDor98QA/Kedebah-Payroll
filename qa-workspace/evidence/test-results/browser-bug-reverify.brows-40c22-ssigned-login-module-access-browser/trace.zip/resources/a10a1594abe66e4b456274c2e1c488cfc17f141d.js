function o(m){const t=Number(m),n=Number.isFinite(t)?t:0;return`₵${new Intl.NumberFormat("en-GH",{minimumFractionDigits:2,maximumFractionDigits:2}).format(n)}`}export{o as f};
